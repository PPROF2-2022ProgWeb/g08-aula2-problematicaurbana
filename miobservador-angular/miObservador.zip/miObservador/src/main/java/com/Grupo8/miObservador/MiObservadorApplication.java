package com.Grupo8.miObservador;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MiObservadorApplication {

	public static void main(String[] args) {
		SpringApplication.run(MiObservadorApplication.class, args);
	}

}
